/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=10x10 boxer boxer.jpg 
 * Time-stamp: Monday 04/04/2022, 17:07:16
 * 
 * Image Information
 * -----------------
 * boxer.jpg 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BOXER_H
#define BOXER_H

extern const unsigned short boxer[100];
#define BOXER_SIZE 200
#define BOXER_LENGTH 100
#define BOXER_WIDTH 10
#define BOXER_HEIGHT 10

#endif

