The World's Easiest Game!
 - In the World's Easiest Game there is no way to lose you can move around and will never lose.
Controls:
  Start --> enter
  Select --> backspace
  Up --> up arrow key
  Down --> down arrow key
  Right --> right arrow key
  Left -- > left arrow key